package kr.re.kitri.db;

public class CarInfoVO {

    public String[] car_name;
    public long[] car_price;
    public String[] car_fuel_type;
    public String[] car_eco_grade;
//    public String[] bt_type;
//    public double[] bt_volt;
//    public double[] bt_vol;
//    public double[] bt_charge_vol;
//    public int[] motor_max_power;
//    public double[] motor_max_torque;

}
