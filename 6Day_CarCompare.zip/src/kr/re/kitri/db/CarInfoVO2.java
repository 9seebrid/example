package kr.re.kitri.db;

public class CarInfoVO2 {

    public String[] bt_type = {"리튬 이온 폴리머","리튬 이온 폴리머","리튬 이온 폴리머","리튬 이온 폴리머"};
    public double[] bt_volt = {522.7, 522.7, 522.7, 522.7};
    public double[] bt_vol = {111.2, 111.2,111.2,111.2};
    public double[] bt_charge_vol = {58.0,58.0,58.0,58.0};
    public int[] motor_max_power = {170,170,170,235};
    public double[] motor_max_torque = {35.7, 35.7, 35,7, 61.7};


}
