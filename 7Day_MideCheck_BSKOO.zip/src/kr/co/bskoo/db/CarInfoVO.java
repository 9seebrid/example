package kr.co.bskoo.db;

public class CarInfoVO {

    public String car_name;
    public String car_price;
}
