package kr.re.kitri.db;

public class CarInfoVO {
	
	public String[] car_name;
	public long[] car_price;
	public String[] car_fuel_type;
	public String[] car_eco_grade;

}
